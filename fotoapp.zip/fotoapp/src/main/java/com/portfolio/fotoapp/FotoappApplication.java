package com.portfolio.fotoapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FotoappApplication {

	public static void main(String[] args) {
		SpringApplication.run(FotoappApplication.class, args);
	}

}
