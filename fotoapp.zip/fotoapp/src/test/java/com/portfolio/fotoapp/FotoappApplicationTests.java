package com.portfolio.fotoapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FotoappApplicationTests {

	@Test
	void contextLoads() {
	}

}
